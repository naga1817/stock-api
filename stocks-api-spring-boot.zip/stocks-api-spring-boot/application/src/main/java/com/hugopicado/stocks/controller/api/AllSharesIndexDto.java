package com.hugopicado.stocks.controller.api;

public class AllSharesIndexDto {

    private Double allSharesIndex;

    public Double getAllSharesIndex() {
        return allSharesIndex;
    }

    public void setAllSharesIndex(Double allSharesIndex) {
        this.allSharesIndex = allSharesIndex;
    }
}
